Cliente de Establecimientos
===========================

EstablecimientoClient
---------------------
.. autoclass:: mpi_client.client.EstablecimientoClient
   :members:

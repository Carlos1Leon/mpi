.. MPIClient documentation master file, created by
   sphinx-quickstart on Tue Jun 20 10:49:23 2017.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Documentación de  MPIClient
===========================

Instalación
-----------

Instalar con PIP:

.. code-block:: sh

   pip install -U git+ssh://git@git.minsa.gob.pe/oidt/mpi-client.git@develop#egg=mpi_client


Para utilizar el cliente MPIClient, debe asegurarse de contar con las variables
de entorno:

.. code-block:: sh

   MPI_API_HOST
   MPI_API_TOKEN


.. toctree::
   :maxdepth: 2
   :caption: Contenido:

   mpiclient
   ciudadano
   establecimiento


Indice
------

* :ref:`genindex`

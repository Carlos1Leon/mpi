Cliente MPI
===========

MPIClient
---------
.. autoclass:: mpi_client.client.MPIClient
   :members:
   :undoc-members:

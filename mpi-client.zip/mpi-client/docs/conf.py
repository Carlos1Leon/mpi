#!/usr/bin/env python3
# -*- coding: utf-8 -*-
#
# MPIClient documentation build configuration file, created by
# sphinx-quickstart on Tue Jun 20 10:49:23 2017.
#
#
import os
import sys

sys.path.insert(0, os.path.abspath('..'))
extensions = ['sphinx.ext.autodoc',
              'sphinx.ext.intersphinx',
              'sphinx.ext.coverage',
              'sphinx.ext.ifconfig',
              'sphinx.ext.viewcode']
templates_path = ['_templates']
source_suffix = '.rst'
master_doc = 'index'
project = 'MPIClient'
copyright = '2017, CJ'
author = 'CJ'
version = '1.4'
release = '1.4.3'
language = 'es'
exclude_patterns = ['_build', 'Thumbs.db', '.DS_Store']
pygments_style = 'sphinx'
todo_include_todos = False
html_theme = 'sphinx_rtd_theme'
html_static_path = ['_static']
htmlhelp_basename = 'MPIClientdoc'
latex_elements = {}
latex_documents = [
    (master_doc, 'MPIClient.tex', 'MPIClient Documentation',
     'CJ', 'manual'),
]
man_pages = [
    (master_doc, 'mpiclient', 'MPIClient Documentation',
     [author], 1)
]
texinfo_documents = [
    (master_doc, 'MPIClient', 'MPIClient Documentation',
     author, 'MPIClient', 'API Client to work with data from MPI server.',
     'Miscellaneous'),
]
intersphinx_mapping = {'https://docs.python.org/': None}

Cliente de Ciudadano
====================

CiudadanoClient
---------------
.. autoclass:: mpi_client.client.CiudadanoClient
   :members:

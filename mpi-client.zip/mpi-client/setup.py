import os

from setuptools import setup

from mpi_client import version


def read(fname):
    return open(os.path.join(os.path.dirname(__file__), fname)).read()


setup(
    name='mpi_client',
    version=version,
    license='BSD',
    description='Aplicación cliente para consultar a la API MPI del MINSA.',
    long_description=read('README.md'),
    author='ODT',
    author_email='cdelgado@minsa.gob.pe',
    url='http://git.minsa.gob.pe/oidt/mpi-client',
    download_url='http://git.minsa.gob.pe/oidt/mpi-client/repository/archive.tar.gz?ref=develop',
    keywords=['mpi', 'minsa', ],
    packages=['mpi_client'],
    classifiers=[
        'Development Status :: 1 - Beta',
        'Intended Audience :: Developers',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Topic :: Internet :: WWW/HTTP',
    ],
    include_package_data=True,
    zip_safe=False,
    install_requires=['requests']
)

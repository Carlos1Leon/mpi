import os
import unittest

import responses

from mpi_client.client import CiudadanoClient, EstablecimientoClient, MPIClient

MPI_API_TOKEN = 'foo'
MPI_API_HOST = os.environ.get('MPI_API_HOST', 'http://devciudadano.minsa.gob.pe')


class TestMPIClient(unittest.TestCase):
    def setUp(self):
        self.client = MPIClient(MPI_API_TOKEN)
        self.client.__mpi_api_url__ = MPI_API_HOST

    def test_api_url(self):
        self.assertEqual(self.client.__mpi_api_url__, MPI_API_HOST)

    @responses.activate
    def test_api_connection(self):
        url_test = "{mpi_host}/api/v1/".format(mpi_host=MPI_API_HOST)
        responses.add(responses.GET, url_test, body='', status=200)
        response = self.client.get(url_test)
        self.assertEqual(response.status_code, 200)


class TestCiudadanoClient(unittest.TestCase):
    def setUp(self):
        self.client = CiudadanoClient(MPI_API_TOKEN)
        self.client.__mpi_api_url__ = MPI_API_HOST

    @responses.activate
    def test_api_get_ciudadano_dni(self):
        url_test = "{mpi_host}/api/v1/ciudadano/ver/01/12345678/".format(mpi_host=MPI_API_HOST)
        expected_json = {'data': {'attributes': {'numero_documento': "12345678"}}}
        responses.add(responses.GET, url_test, json=expected_json, status=200)
        response = self.client.ver("12345678")
        doc_resp = response.get('numero_documento')
        self.assertEqual(doc_resp, '12345678')

    @responses.activate
    def test_api_get_ciudadano_uuid(self):
        uuid_test = '42176fa2-cd1f-4232-8ac5-489bbdef85e4'
        url_test = "{mpi_host}/api/v1/ciudadano/ver/{uuid}/".format(mpi_host=MPI_API_HOST, uuid=uuid_test)
        expected_json = {'data': {'attributes': {'numero_documento': "12345678"}}}
        responses.add(responses.GET, url_test, json=expected_json, status=200)
        response = self.client.ver(uuid_test)
        doc_resp = response.get('numero_documento')
        self.assertEqual(doc_resp, '12345678')

    @responses.activate
    def test_api_crear_sin_documento(self):
        url_test = "{mpi_host}/api/v1/ciudadano/crear/".format(mpi_host=MPI_API_HOST)
        expected_json = {'data': {
            'attributes': {'numero_documento': "SD-00000001", 'nombres': 'Pepito', 'apellido_paterno': 'Grillo'}}}
        responses.add(responses.POST, url_test, json=expected_json, status=200)
        response = self.client.crear_sin_documento({'nombres': 'Pepito', 'apellido_paterno': 'Grillo'})
        self.assertEqual(response,
                         {'numero_documento': "SD-00000001", 'nombres': 'Pepito', 'apellido_paterno': 'Grillo'})


class TestEstablecimientoClient(unittest.TestCase):
    def setUp(self):
        self.client = EstablecimientoClient(MPI_API_TOKEN)
        self.client.__mpi_api_url__ = MPI_API_HOST

    @responses.activate
    def test_ver_establecimiento(self):
        codigo_renaes = '6207'
        url_test = "{mpi_host}/api/v1/establecimiento/{codigo_renaes}/detalle/".format(mpi_host=MPI_API_HOST,
                                                                                       codigo_renaes=codigo_renaes)
        expected_json = {'data': {'attributes': {'sector_nombre': 'MINSA', 'nombre': 'NACIONAL ARZOBISPO LOAYZA',
                                                 'direccion': 'AV. ALFONSO UGARTE 848', 'codigo_renaes': '6207'}}}
        responses.add(responses.GET, url_test, json=expected_json, status=200)
        response = self.client.ver(codigo_renaes)
        self.assertEqual(response.get('codigo_renaes'), codigo_renaes)

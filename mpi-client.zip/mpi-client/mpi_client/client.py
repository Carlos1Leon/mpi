# coding=utf-8
"""
Cliente para consumir servicios de MPI

MINSA (c) 2017
"""
import json
import os
import re

import requests

from mpi_client import version

MPI_API_HOST = os.environ.get('MPI_API_HOST', '')
APP_IDENTIFIER = os.environ.get('APP_IDENTIFIER', '-')


class BaseClient(object):
    """Clase Base de cliente MPI que recibe el token de autorización como parámetro de instancia."""

    def __init__(self, client_token):
        self.__client_token__ = client_token
        self.__mpi_api_url__ = MPI_API_HOST if not MPI_API_HOST.endswith('/') else MPI_API_HOST[:-1]
        self.timeout = 45
        self.client_headers = {
            'User-Agent': 'MPIClient {} :: {}'.format(version, APP_IDENTIFIER),
            'App-Identifier': APP_IDENTIFIER,
            'Authorization': 'Bearer {token}'.format(token=self.__client_token__)
        }


class MPIClient(BaseClient):
    """Wrapper de `requests` que sobreescribe el header de la petición HTTP con el token de autorización."""

    def get(self, url, params=None, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.get(url, params, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def options(self, url, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.options(url, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def head(self, url, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.head(url, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def post(self, url, data=None, json=None, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.post(url, data, json, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def put(self, url, data=None, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.put(url, data, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def patch(self, url, data=None, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.patch(url, data, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def delete(self, url, **kwargs):
        kwargs.update({'headers': self.client_headers, 'timeout': self.timeout})
        try:
            response = requests.delete(url, **kwargs)
            return response
        except requests.Timeout:
            return {'error': 'Timeout error'}


class CiudadanoClient(BaseClient):
    """Cliente para manejo de datos de Ciudadanos utilizando el API de MPI."""

    def ver(self, numero_documento_or_uuid, tipo_documento='01', actualizar_sis=False, trama_auditoria={}):
        """
        Retorna data de ciudadano desde MPI

        Tipos de documento soportados:

        * '00' = No se conoce
        * '01' = DNI
        * '02' = Libreta Militar
        * '03' = Carnet de extrajeria
        * '04' = Acta de nacimiento
        * '06' = Pasaporte
        * '07' = Documento de Identificación del Extranjero

        :param numero_documento_or_uuid: Número de documento de identidad del ciudadano, o UUID de objeto.
        :param tipo_documento: Tipo de documento de identidad del ciudadano.
        :param actualizar_sis: Variable para forzar actualización de datos SIS.
        :return: Diccionario con data de ciudadano o con datos de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}

        def ver_numero_documento(numero_documento, tipo_doc):
            url = "{server}/api/v1/ciudadano/ver/{tipo_doc}/{nro_documento}/?actualizar_sis={actualizar_sis}".format(
                server=self.__mpi_api_url__,
                tipo_doc=tipo_doc,
                nro_documento=numero_documento,
                actualizar_sis=1 if actualizar_sis else 0,
            )
            self.client_headers.update({
                'EESS-Identifier': trama_auditoria.get('codigo_eess', ''),
                'Tipo-Documento-Identifier': trama_auditoria.get('tipo_documento', ''),
                'Numero-Documento-Identifier': trama_auditoria.get('numero_documento', ''),
            })
            try:
                response = requests.get(url, headers=self.client_headers, timeout=self.timeout)
                if response.status_code == 200:
                    return response.json().get('data').get('attributes')
                try:
                    return json.loads(response.content.decode())
                except json.JSONDecodeError:
                    return {'error': response.reason}
            except requests.Timeout:
                return {'error': 'Timeout error'}

        def ver_uuid(uuid):
            url = "{server}/api/v1/ciudadano/ver/{uuid}/?actualizar_sis={actualizar_sis}".format(
                server=self.__mpi_api_url__,
                uuid=uuid,
                actualizar_sis=1 if actualizar_sis else 0,
            )
            try:
                response = requests.get(url, **kwargs)
                if response.status_code == 200:
                    return response.json().get('data').get('attributes')
                try:
                    return json.loads(response.content.decode())
                except json.JSONDecodeError:
                    return {'error': response.reason}
            except requests.Timeout:
                return {'error': 'Timeout error'}

        if re.match(r'^\d{6,15}$', numero_documento_or_uuid):
            return ver_numero_documento(numero_documento_or_uuid, tipo_documento)
        elif re.match(r'^SD-\w+$', numero_documento_or_uuid):
            return ver_numero_documento(numero_documento_or_uuid, '00')
        elif tipo_documento not in ('01', '03') and re.match(r'^\w{6,15}$', numero_documento_or_uuid):
            return ver_numero_documento(numero_documento_or_uuid, tipo_documento)
        else:
            return ver_uuid(numero_documento_or_uuid)

    def ver_datos_sis(self, numero_documento_or_uuid, tipo_documento='01'):
        """
        Retorna dato de SIS de ciudadano desde MPI

        Tipos de documento soportados:

        * '00' = No se conoce
        * '01' = DNI
        * '02' = Libreta Militar
        * '03' = Carnet de extrajeria
        * '04' = Acta de nacimiento
        * '06' = Pasaporte
        * '07' = Documento de Identificación del Extranjero

        :param numero_documento_or_uuid: Número de documento de identidad del ciudadano, o UUID de objeto.
        :param tipo_documento: Tipo de documento de identidad del ciudadano.
        :return: Diccionario con información de SIS de ciudadano o datos de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}

        def ver_numero_documento(numero_documento, tipo_doc):
            url = "{server}/api/v1/ciudadano/datos-sis/{tipo_documento}/{numero_documento}/".format(
                server=self.__mpi_api_url__, tipo_documento=tipo_doc, numero_documento=numero_documento)
            try:
                response = requests.get(url, **kwargs)
                if response.status_code == 200:
                    return response.json().get('data').get('attributes')
                try:
                    return json.loads(response.content.decode())
                except json.JSONDecodeError:
                    return {'error': response.reason}
            except requests.Timeout:
                return {'error': 'Timeout error'}

        def ver_uuid(uuid):
            url = "{server}/api/v1/ciudadano/datos-sis/{uuid}/".format(server=self.__mpi_api_url__, uuid=uuid)
            try:
                response = requests.get(url, **kwargs)
                if response.status_code == 200:
                    return response.json().get('data').get('attributes')
                try:
                    return json.loads(response.content.decode())
                except json.JSONDecodeError:
                    return {'error': response.reason}
            except requests.Timeout:
                return {'error': 'Timeout error'}

        if re.match(r'^\d{6,15}$', numero_documento_or_uuid):
            return ver_numero_documento(numero_documento_or_uuid, tipo_documento)
        elif re.match(r'^SD-\w+$', numero_documento_or_uuid):
            return ver_numero_documento(numero_documento_or_uuid, '00')
        else:
            return ver_uuid(numero_documento_or_uuid)

    def crear_sin_documento(self, data):
        """
        Crea un ciudadano sin documento de indentidad en la base de datos de MPI.

        :param data: Diccionario de datos que serán ingresados a la base de datos de MPI.
        :return: Diccionario con objeto creado o con datos de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/crear/".format(server=self.__mpi_api_url__)
        try:
            ciudadano_sd = {'tipo_documento': '00', 'tipo_documento_minsa': '0', 'numero_documento': ''}
            data.update(ciudadano_sd)
            response = requests.post(url, data=data, **kwargs)
            if response.status_code == 200:
                return response.json().get('data').get('attributes')
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def crear_ciudadano_otro_tipo_documento(self, data):
        """
        Crea un ciudadano con otro tipo de documento que no sea DNI y no sea sin documento.

        :param data:  Diccionario de datos que serán ingresados a la BD de MPI
        :return: Diccionario con objeto creado o datos de errores
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/crear/".format(server=self.__mpi_api_url__)
        if data.get('tipo_documento') in ('00', '01', '03', '0', '1', '2'):
            raise Exception("El tipo de documento no puede ser '00', '01' ni '03'.")
        try:
            response = requests.post(url, data=data, **kwargs)
            if response.status_code == 200:
                return response.json().get('data').get('attributes')
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def buscar(self, apellido_paterno=None, apellido_materno=None, nombres=None, numero_documento=None):
        """
        Busca ciudadanos que coincidan con los parámetros de búsqueda.

        :param apellido_paterno: Apellido paterno de (los) ciudadano(s) a buscar.
        :param apellido_materno: Apellido materno de (los) ciudadano(s) a buscar.
        :param nombres:  Nombre(s) de (los) ciudadano(s) a buscar.
        :param numero_documento: Número de documento de (los) ciudadano(s) a buscar.
        :return: Lista con data de búsqueda o diccionario con datos de errores.
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/buscar/".format(server=self.__mpi_api_url__)
        try:
            params = {
                'ap_paterno': apellido_paterno, 'ap_materno': apellido_materno, 'nombres': nombres,
                'numero_documento': numero_documento
            }
            response = requests.get(url, params=params, **kwargs)
            if response.status_code == 200:
                return [ciudadano.get('attributes') for ciudadano in response.json().get('data')]
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def buscar_dni(self, numero_dni):
        """
        Función deprecada, se eliminará en v2.0. Usar `buscar_dni_registro_previo(numero_dni)` en su lugar.

        :param numero_dni: Número de DNI de ciudadano.
        :return: Lista con resultados de búsqueda.
        :rtype: list
        """
        return self.buscar_dni_registro_previo(numero_dni)

    def buscar_dni_registro_previo(self, numero_dni):
        """
        Busca entre los ciudadanos indocumentados cualquier coincidencia con un registro obtenido de RENIEC con el
        número de documento enviado en el parámetro de búsqueda,  de encontrar varias coincidencias,  devuelve una
        lista con  los  resultados encontrados,  de encontrar una sola coincidencia,  asigna el  DNI  al resultado
        encontrado y actualiza datos con los obtenidos en la consulta a RENIEC y devuelve el resultado.

        :param numero_dni: Número de DNI de ciudadano.
        :return: Lista con resultados de búsqueda.
        :rtype: list
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/buscardni/{numero_dni}/".format(server=self.__mpi_api_url__,
                                                                         numero_dni=numero_dni)
        try:
            response = requests.get(url, **kwargs)
            if response.status_code == 200:
                return [ciudadano.get('attributes') for ciudadano in response.json().get('data')]
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def actualizar(self, data, ubigeo_provider='inei', numero_documento=None, tipo_documento='01', uuid=None):
        """
        Actualiza datos de ciudadano.

        :param data: Diccionario de datos que contienen los valores a modificar.
        :param ubigeo_provider:  Proveedor de ubigeo (`inei` o `reniec`).
        :param numero_documento: Número de documento de identidad del ciudadano.
        :param tipo_documento: Tipo de documento de identidad del ciudadano.
        :param uuid: UUID de objeto ciudadano.
        :return: Diccionario de datos actualizados o diccionario con contenido de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/actualizar".format(server=self.__mpi_api_url__)
        try:
            if uuid:
                url = "{url}/{uuid}/".format(url=url, uuid=uuid)
            elif numero_documento and tipo_documento:
                url = "{url}/{tipo_documento}/{numero_documento}/".format(url=url, tipo_documento=tipo_documento,
                                                                          numero_documento=numero_documento)
            data.update({'ubigeo_provider': ubigeo_provider})
            response = requests.patch(url, data=data, **kwargs)
            if response.status_code == 200:
                return response.json().get('data').get('attributes')
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def registrar_antecedente(self, numero_documento, tipo_documento, id_ciex, fecha_inicio, fecha_fin, observaciones,
                              tipo_antecedente):
        """
        Registra antecedente médico del paciente que se está atendiendo.

        :param numero_documento: Número de documento de identidad del ciudadano.
        :param tipo_documento: Tipo de documento de identidad del ciudadano.
        :param id_ciex: Código CIEX de diagnóstico.
        :param fecha_inicio: Fecha de inicio de antecedente.
        :param fecha_fin: Fecha de fin de antecedente.
        :param observaciones: Observaciones.
        :param tipo_antecedente: 1: Personal, 2: Gineco-Obstetra, 3: Patológico, 4: Psicológico.
        :return: Diccionario con antecedente creado o con datos de error.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/antecedente/".format(server=self.__mpi_api_url__)
        data = {
            'tipo_documento': tipo_documento,
            'numero_documento': numero_documento,
            'id_ciex': id_ciex,
            'fecha_inicio': fecha_inicio,
            'fecha_fin': fecha_fin,
            'observaciones': observaciones,
            'tipo_antecedente': tipo_antecedente,
        }
        try:
            response = requests.post(url, data=data, **kwargs)
            if response.status_code == 200:
                return response.json()
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def listar_antecedentes(self, numero_documento, tipo_documento='01'):
        """
        Lista antecedentes médicos registrados del paciente.

        :param numero_documento:  Número de documento de identidad del ciudadano.
        :param tipo_documento:  Tipo de documento de identidad del ciudadano.
        :return: Lista de antecedentes registrados o diccionario con datos de errores.
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/antecedente/{tipo_documento}/{numero_documento}/".format(
            server=self.__mpi_api_url__, tipo_documento=tipo_documento, numero_documento=numero_documento)
        try:
            response = requests.get(url, **kwargs)
            if response.status_code == 200:
                return [antecedente.get('attributes') for antecedente in response.json().get('data')]
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def registrar_antecedente_familiar(self, numero_documento, tipo_documento, parentesco, id_ciex,
                                       fecha_inicio, fecha_fin, observaciones):
        """
        Registra antecedente médico de un familiar del paciente que se está atendiendo.

        :param numero_documento: Número de documento de identidad del ciudadano.
        :param tipo_documento: Tipo de documento de identidad del ciudadano.
        :param parentesco: Parentesco con el familiar:  1: Padre, 2: Madre, 3: Hijo, 4: Hija.
        :param id_ciex: Código CIEX de diagnóstico del familiar.
        :param fecha_inicio: Fecha de inicio de antecedente del familiar.
        :param fecha_fin: Fecha de fin de antecedente del familiar.
        :param observaciones: Observaciones.
        :return: Diccionario con antecedente creado o con datos de error.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/antecedentefam/".format(server=self.__mpi_api_url__)
        data = {
            'numero_documento': numero_documento,
            'tipo_documento': tipo_documento,
            'parentesco': parentesco,
            'id_ciex': id_ciex,
            'fecha_inicio': fecha_inicio,
            'fecha_fin': fecha_fin,
            'observaciones': observaciones,
        }
        try:
            response = requests.post(url, data=data, **kwargs)
            if response.status_code == 200:
                return response.json()
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def listar_antecedentes_familiares(self, numero_documento, tipo_documento='01'):
        """
        Lista antecedentes médicos registrados de familiares del paciente.

        :param numero_documento:  Número de documento de identidad del ciudadano.
        :param tipo_documento:  Tipo de documento de identidad del ciudadano.
        :return: Lista de antecedentes registrados de familiares o diccionario con datos de errores.
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/antecedentefam/{tipo_documento}/{numero_documento}/".format(
            server=self.__mpi_api_url__, tipo_documento=tipo_documento, numero_documento=numero_documento)
        try:
            response = requests.get(url, **kwargs)
            if response.status_code == 200:
                return [antecedente.get('attributes') for antecedente in response.json().get('data')]
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def validar_dni_codigo_verificacion(self, numero_documento, codigo_verificacion):
        """
        Valida que el DNI y el código de verificación del mismo sean correctos

        :param numero_documento: Número de DNI
        :param codigo_verificacion: Código de verificación
        :return: Diccionario con resultado de verificación o datos de error
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/ciudadano/validar-dni/".format(server=self.__mpi_api_url__)
        try:
            payload = {
                'numero_documento': numero_documento,
                'codigo_verificacion': codigo_verificacion,
            }
            response = requests.post(url, payload, **kwargs)
            if response.status_code == 200:
                return response.json()
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}


class EstablecimientoClient(BaseClient):
    """Cliente para manejo de datos de Establecimientos de salud utilizando el API de MPI."""

    def listar_todos(self, cantidad_resultados=10, pagina=1):
        """
        Lista todos los establecimientos de salud, con paginación y ordenados por código renaes.

        :param cantidad_resultados: Cantidad de establecimientos en resultado de lista.
        :param pagina: Número de página de resultados.
        :return: Diccionario con lista de establecimientos y cantidad de páginas, o diccionario de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/establecimientos/".format(server=self.__mpi_api_url__)
        params = {'page': pagina, 'page_size': cantidad_resultados}
        try:
            response = requests.get(url, params, **kwargs)
            if response.status_code == 200:
                return {
                    'paginas': response.json().get('meta', {}).get('pagination', {}).get('pages'),
                    'data': [estab.get('attributes') for estab in response.json().get('data')]
                }
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def buscar_establecimiento(self, parametro, sector='all', cantidad_resultados=10, pagina=1):
        """
        Busca establecimientos que coincidan con el valor ingresado en `parametro`.

        :param parametro: Valor para realizar búsqueda, acepta valores de  *código renaes*,
                          *nombre de establecimiento* o *nombre de microred*.
        :param sector: Sectores para filtrar establecimientos en resultado de búsqueda.
        :param cantidad_resultados: Cantidad de establecimientos en resultado de búsqueda.
        :param pagina: Número de página de resultados.
        :return: Diccionario con resultados de búsqueda y cantidad de páginas.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/establecimientos/".format(server=self.__mpi_api_url__)
        params = {'page': pagina, 'page_size': cantidad_resultados, 'q': parametro, 'sector': sector}
        try:
            response = requests.get(url, params, **kwargs)
            if response.status_code == 200:
                return {
                    'paginas': response.json().get('meta', {}).get('pagination', {}).get('pages'),
                    'data': [estab.get('attributes') for estab in response.json().get('data')]
                }
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def ver(self, codigo_renaes):
        """
        Obtiene datos de un establecimiento.

        :param codigo_renaes: Código RENAES de establecimiento que se quiere obtener datos.
        :return: Diccionario con datos del establecimiento o diccionario de errores.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/establecimiento/{codigo_renaes}/detalle/".format(
            server=self.__mpi_api_url__, codigo_renaes=codigo_renaes)
        try:
            response = requests.get(url, **kwargs)
            if response.status_code == 200:
                return response.json().get('data', {}).get('attributes')
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def cercanos(self, longitud, latitud, distancia=5, cantidad_resultados=10, pagina=1):
        """
        Lista de establecimientos cercanos a un punto geográfico, ordenados por distancia más cercana.

        :param longitud: Longitud.
        :param latitud: Latitud.
        :param distancia: Distancia de búsqueda en kilómetros.
        :param cantidad_resultados: Cantidad de establecimientos en resultado de búsqueda.
        :param pagina: Número de página de resultados.
        :return: Diccionario con resultados de búsqueda y cantidad de páginas.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/establecimientos/cercanos/".format(server=self.__mpi_api_url__)
        params = {
            'lon': longitud, 'lat': latitud, 'distancia': distancia,
            'page': pagina, 'page_size': cantidad_resultados
        }
        try:
            response = requests.get(url, params, **kwargs)
            if response.status_code == 200:
                return {
                    'paginas': response.json().get('meta', {}).get('pagination', {}).get('pages'),
                    'data': [estab.get('attributes') for estab in response.json().get('data')]
                }
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def listar_por_ubigeo(self, ubigeo, cantidad_resultados=10, pagina=1):
        """
        Lista todos los establecimientos en un ubigeo determinado.

        :param ubigeo: Codigo de ubigeo.
        :param cantidad_resultados: Cantidad de establecimientos en resultado de búsqueda.
        :param pagina: Número de página de resultados.
        :return: Diccionario con resultados de búsqueda y cantidad de páginas.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url = "{server}/api/v1/establecimientos/ubigeo/{cod_ubigeo}/".format(
            server=self.__mpi_api_url__, cod_ubigeo=ubigeo)
        params = {'page': pagina, 'page_size': cantidad_resultados}
        try:
            response = requests.get(url, params, **kwargs)
            if response.status_code == 200:
                return {
                    'paginas': response.json().get('meta', {}).get('pagination', {}).get('pages'),
                    'data': [estab.get('attributes') for estab in response.json().get('data')]
                }
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}

    def listar_por_diresa_red_microred(self, diresa, red=None, microred=None, cantidad_resultados=10, pagina=1):
        """
        Lista todos los establecimientos dentro de una DIRESA, RED y/o MICRORED que se establezca(n).

        :param diresa: Código de DIRESA.
        :param red: Código de RED.
        :param microred: Código de MICRORED (se debe establecer el parámetro `red` para acceder a una microred).
        :param cantidad_resultados: Cantidad de establecimientos en resultado de búsqueda.
        :param pagina: Número de página de resultados.
        :return: Diccionario con resultados de búsqueda y cantidad de páginas.
        :rtype: dict
        """
        kwargs = {'headers': self.client_headers, 'timeout': self.timeout}
        url_base = "{server}/api/v1/establecimientos".format(server=self.__mpi_api_url__)
        url = "{url_base}/diresa/{diresa}/".format(url_base=url_base, diresa=diresa)
        if red and microred:
            url += "red/{red}/microred/{microred}/".format(red=red, microred=microred)
        elif red:
            url += "red/{red}/".format(red=red)
        params = {'page': pagina, 'page_size': cantidad_resultados}
        try:
            response = requests.get(url, params, **kwargs)
            if response.status_code == 200:
                return {
                    'paginas': response.json().get('meta', {}).get('pagination', {}).get('pages'),
                    'data': [estab.get('attributes') for estab in response.json().get('data')]
                }
            try:
                return json.loads(response.content.decode())
            except json.JSONDecodeError:
                return {'error': response.reason}
        except requests.Timeout:
            return {'error': 'Timeout error'}
